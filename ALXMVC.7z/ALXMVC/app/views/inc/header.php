<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="<?php echo URLROOT; ?>/css/style.css">
	<title><?php echo SITENAME; ?></title>
</head>
<body>

