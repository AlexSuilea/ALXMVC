
<script src="<?php echo URLROOT; ?>/js/main.js"></script>
</body>
</html>